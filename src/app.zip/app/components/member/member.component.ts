import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MemberDataService } from 'src/app/services/member-data.service';
import { LotteryService } from '../../services/lottery.service';

import { CartService } from 'src/app/services/cart.service'; 

@Component({
  selector: 'app-member',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.css']
})
export class MemberComponent {
  cartItems: any[] = [];
  constructor(private lotteryService: LotteryService,
     private router: Router,
     private memberDataService: MemberDataService,
     private cartService: CartService,

     ) { }
  memberName: string | null = null;
  ngOnInit() {
    // ดึงรายการสินค้าจาก CartService
    this.cartService.getItems().subscribe((items) => {
      this.cartItems = items;
    });

    // ดึงชื่อสมาชิกจาก MemberDataService
    this.memberName = this.memberDataService.getMemberName();
  }
  isUserLoggedIn(): boolean {
    return this.lotteryService.isLoggedIn;
  }

  logout() {
     this.memberDataService.clearMemberName();
    this.lotteryService.isLoggedIn = false;
    this.router.navigate(['/home']); // เด้งไปยังหน้า home
  }
  calculateTotalItems(): number {
    return this.cartItems.reduce((total, item) => {
      if (item.quantity !== undefined) {
        return total + item.quantity;
      } else {
        return total;
      }
    }, 0);
  }
}
