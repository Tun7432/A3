import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-lottery-report',
  templateUrl: './admin-lottery-report.component.html',
  styleUrls: ['./admin-lottery-report.component.css']
})
export class AdminLotteryReportComponent {

}
