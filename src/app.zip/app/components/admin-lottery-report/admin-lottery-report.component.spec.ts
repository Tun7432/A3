import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminLotteryReportComponent } from './admin-lottery-report.component';

describe('AdminLotteryReportComponent', () => {
  let component: AdminLotteryReportComponent;
  let fixture: ComponentFixture<AdminLotteryReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminLotteryReportComponent]
    });
    fixture = TestBed.createComponent(AdminLotteryReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
